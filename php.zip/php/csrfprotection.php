<?php 
error_reporting(0);
session_start();

if(!isset($token)) {
    $token = md5(uniqid());
    // $_SESSION['token'] = $token;
    // $_SESSION['token_time'] = time();
}

if(isset($_POST['check'])){
	echo "HIdden field: ".$_POST['token'].'<br>';
	echo "First token: ".$token.'<br>';
	if($_POST['token'] == $token){
		echo "Yes";
	}else{
		echo "No";
	}
}

?>
<form method="post">
<input type='hidden' name='token' value="<?php echo $token; ?>"/>
<input type='text' name='name'/>
<input type='submit' name='check' value='check'/>
</form>