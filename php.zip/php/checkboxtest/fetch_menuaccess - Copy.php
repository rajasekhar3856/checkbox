<?php
$dbconn = mysqli_connect("localhost","root","","test");
if(isset($_POST["call_id"]))
 {  
	$query = "SELECT * FROM tbl_test_menuaccess WHERE id = '".$_POST["call_id"]."'";  
      $result = mysqli_query($dbconn, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);
	  
 }  
?>
