<?php

// error_reporting(0);
// setcookie("id","2",time()+5);
// setcookie("name","Raja",time()+8);
// echo $_COOKIE['id']."<br>";
// echo $_COOKIE['name'];


$date = '0000-00-00';
if($date != '0000-00-00'){
	// echo '-';
}else{
	// echo $date;
}

session_start();
 $id = session_id();
 $id.' Hello';

        $SessionID = openssl_random_pseudo_bytes(64);
        setcookie("SESSION_ID",$SessionID, time()*3600);
		
	if(empty($_COOKIE["SESSION_ID"])){
		// print_r($_COOKIE);
	}
	
	setcookie("id","123456");
	if($_COOKIE["id"]){
		setcookie("id","115341");
		echo $_COOKIE["id"];
		
	}else{
		echo "No";
		
	}
	
$a = session_id();
if(empty($a)) session_start();
echo "SID: ".SID."<br>session_id(): ".session_id()."<br>COOKIE: ".$_COOKIE["PHPSESSID"];
?>
