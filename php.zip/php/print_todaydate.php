<?
echo Date('Y-m-d h:i:s');
?>