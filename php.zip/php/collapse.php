<?
echo phpinfo();
?>