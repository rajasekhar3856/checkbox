<?php

echo $_COOKIE['name'];
echo $_COOKIE['id'];
?>