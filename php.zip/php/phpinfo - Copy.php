<?php
phpinfo();
session_start();
$string = "raja";
 $token= md5(uniqid());
//echo $token;
$_SESSION['start'] = time();
// echo $_SESSION['start']."<br>";
$_SESSION['expire'] = $_SESSION['start']+ (1*60);
$now = time();
if($now > $_SESSION['expire']){
	// echo "Yes";
	}else{
		// echo "No";
	}


//echo $string.'<br>';

$string2 = htmlspecialchars($string, ENT_QUOTES, 'UTF-8').'<br>';
// echo $string2;

$string1 = utf8_encode(htmlentities(strip_tags($string),ENT_QUOTES)).'<br>';
// echo $string1;
$str = "\x8F!!!";

// Outputs an empty string
// echo htmlentities($str, ENT_QUOTES, "UTF-8").'<br>';

// Outputs "!!!"
// echo htmlentities($str, ENT_QUOTES | ENT_IGNORE, "UTF-8").'<br>';



?>