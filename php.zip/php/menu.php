<html>
<body>
<a href="http://www.example.com/index.php">Home</a> - 
<a href="http://www.example.com/about.php">About Us</a> - 
<a href="http://www.example.com/links.php">Links</a> - 
<a href="http://www.example.com/contact.php">Contact Us</a> <br />