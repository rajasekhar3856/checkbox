<?php 
// phpinfo();
$tdate=date("Y-m-d");
$timen=date("H:i:s");
echo "Date is : ".$tdate;
echo "<br>";
echo "time is : ".$timen;
?>