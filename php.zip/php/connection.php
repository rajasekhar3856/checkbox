<?php

$dbconn = mysqli_connect("10.2.1.129","root","",qaportal_etas );
if($dbconn){
	echo "Done";
}else{
	echo "Not connect";
}

?>