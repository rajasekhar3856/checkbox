<? require('dbconn.php'); ?>
<style>
table, tr, td, th
{
    border: 1px solid black;
    border-collapse:collapse;
}

img.button_open{
  content:url('button-open.png');
  cursor:pointer;
}

img.button_closed{
  content: url('button-closed.png');
  cursor:pointer;
}
</style>
<table border="0">
  <tr>
      <th>Header 1</th>
      <th>Header 2</th>
  </tr>
<?
$selstep = mysqli_query($dbconn,"SELECT * FROM `tbl_core_wbs` WHERE wbs_step = 1");
while($getselstep = mysqli_fetch_array($selstep)){
	$rand1 = uniqid();
?>
  
  <tr>
    <td id="group2" class='group2<? echo $rand1; ?>' name="group2name"><? echo $getselstep['wbs_code'];?></td>
    <td>data 2</td>
  </tr>
  <? $_selstep2 = mysqli_query($dbconn,"SELECT * FROM `tbl_core_wbs` WHERE wbs_category LIKE '".$getselstep['wbs_proj_code']."%' and wbs_step = 2");
	while($_getselstep2 = mysqli_fetch_array($_selstep2)){ 
	$rand2 = uniqid();
   ?>
  <tr class='group2<? echo $rand1; ?>'>
    <td id="sub_group1" class='sub_group1<? echo $rand2; ?>' name="subgroup2name"><? echo $_getselstep2['wbs_code'];?></td>
    <td>data 6</td>
  </tr>
  <? 
	$_selstep3 = mysqli_query($dbconn,"SELECT * FROM `tbl_core_wbs` WHERE wbs_code LIKE '".$_getselstep2['wbs_category']."%' and wbs_step = 3");
	while($_getselstep3 = mysqli_fetch_array($_selstep3)){
	?>
  <tr class='group2<? echo $rand1; ?> sub_group1<? echo $rand2; ?>'>
    <td><? echo $_getselstep3['wbs_code'];?></td>
    <td>data 8</td>
  </tr>
  
	<? } ?>
	<? } ?>
	
<? } ?>
  
</table>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
function CreateGroup(group_name)
{
    // Create Button(Image)
    $('td.' + group_name).prepend("<img class='" + group_name + " button_closed'> ");
    // Add Padding to Data
    $('tr.' + group_name).each(function () {
        var first_td = $(this).children('td').first();
        var padding_left = parseInt($(first_td).css('padding-left'));
        $(first_td).css('padding-left', String(padding_left + 25) + 'px');
    });
    RestoreGroup(group_name);
    
    // Tie toggle function to the button
    $('img.' + group_name).click(function(){
        ToggleGroup(group_name);
    });
}

function ToggleGroup(group_name)
{
    ToggleButton($('img.' + group_name));
    RestoreGroup(group_name);
}

function RestoreGroup(group_name)
{
    if ($('img.' + group_name).hasClass('button_open'))
    {
        // Open everything
        $('tr.' + group_name).show();
        
        // Close subgroups that been closed
        $('tr.' + group_name).find('img.button_closed').each(function () {
            sub_group_name = $(this).attr('class').split(/\s+/)[0];
            //console.log(sub_group_name);
            RestoreGroup(sub_group_name);
        });
    }
    
    if ($('img.' + group_name).hasClass('button_closed'))
    {
        // Close everything
        $('tr.' + group_name).hide();
    }
}

function ToggleButton(button)
{
    $(button).toggleClass('button_open');
    $(button).toggleClass('button_closed');
}


// var classname1 = document.getElementById('group2');
// var classname2 = document.getElementById('sub_group1');
// alert(classname1.className);
// var x = document.getElementsByClassName("example");
// CreateGroup(classname1.className);
// CreateGroup(classname2.className);

var a = document.getElementsByName('group2name');
	// alert(a.length);
  for (var i = 0; i < a.length; i++) {
 // document.write(a[i].className);
	CreateGroup(a[i].className);
  }

  var b = document.getElementsByName('subgroup2name');
	// alert(a.length);
  for (var i = 0; i < b.length; i++) {
 // document.write(a[i].className);
	CreateGroup(b[i].className);
  }



// CreateGroup('group2');
// CreateGroup('sub_group1');
</script>