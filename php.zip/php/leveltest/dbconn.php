<?php
error_reporting(0);
session_set_cookie_params(0,'/','localhost',true,true);
session_start();
session_regenerate_id(true);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "coretest";
// $username = "coreusr";
// $password = "C0r3U3Sr471s";
// $dbname = "coredb";

// Create connection
$dbconn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if ($dbconn->connect_error) {
    die("Connection failed: " . $dbconn->connect_error);
} 
//echo "Connected successfully";


?>