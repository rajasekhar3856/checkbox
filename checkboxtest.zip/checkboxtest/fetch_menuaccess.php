<div class="modal fade" id="login_for_review" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" style="width:70% !important;" role="document">
		<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title" id="exampleModalLabel">Add Usergroup </h5>
			<span style="padding-right:50px;"><button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button></span>
		  </div>
		  
		  <div class="modal-body">
			<div class="tbl-border">
  <form class="" method="POST" name="_formname">
  <div class="row">
	<div class="col-sm-6">
		 <div class="form-group">
			<label for="exampleInputEmail1">Group Name</label>
			<input type="text" name="groupname" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Group" required>
			
		  </div>
		  <div class="form-group">
			<label for="exampleInputPassword1">Role</label>
			<select name="selectrole" class="form-control" required>
				<option value="">--Select--</option>
				<option value="Admin">Admin</option>
				<option value="Super Admin">Super Admin</option>
				<option value="User">User</option>
			</select>
		  </div>		
	</div>
	  <div class="col-sm-4"></div>
		
	</div>
	<center><input type="submit" value="Submit" name="submit"/></center>
	</form>
	</div>
	
		  </div>
		</div>
	</div>
  </div>
  